"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { operatives } from "@/lib/operatives";
import { loadDay, saveDay } from "@/lib/storage";
import type {
  AttendanceRecord,
  Operative,
  SiteDay,
  TimelineEvent,
} from "@/types/site";

function getTodayDate(): string {
  return new Date().toISOString().split("T")[0];
}

function getCurrentTime(): string {
  return new Date().toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

function normaliseAttendance(
  records: AttendanceRecord[] | undefined
): AttendanceRecord[] {
  if (!Array.isArray(records)) {
    return [];
  }

  return records.map((record) => ({
    ...record,
    operativeId: String(record.operativeId),
    signIn: record.signIn ?? "",
    signOut: record.signOut ?? "",
  }));
}

function timeToMinutes(time?: string): number | null {
  if (!time) {
    return null;
  }

  const [hours, minutes] = time.split(":").map(Number);

  if (
    Number.isNaN(hours) ||
    Number.isNaN(minutes) ||
    hours < 0 ||
    hours > 23 ||
    minutes < 0 ||
    minutes > 59
  ) {
    return null;
  }

  return hours * 60 + minutes;
}

function calculateHours(signIn?: string, signOut?: string): number {
  const start = timeToMinutes(signIn);
  const finish = timeToMinutes(signOut);

  if (start === null || finish === null) {
    return 0;
  }

  const adjustedFinish = finish < start ? finish + 24 * 60 : finish;

  return Math.max(0, (adjustedFinish - start) / 60);
}

function formatHours(hours: number): string {
  return hours.toFixed(2);
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency: "GBP",
  }).format(value);
}

export default function AttendancePage() {
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [events, setEvents] = useState<TimelineEvent[]>([]);
  const [hasLoaded, setHasLoaded] = useState(false);

  useEffect(() => {
    const savedDay = loadDay() as SiteDay | null;

    if (savedDay) {
      setAttendance(normaliseAttendance(savedDay.attendance));
      setEvents(Array.isArray(savedDay.events) ? savedDay.events : []);
    }

    setHasLoaded(true);
  }, []);

  useEffect(() => {
    if (!hasLoaded) {
      return;
    }

    const existingDay = loadDay() as SiteDay | null;

    const updatedDay: SiteDay = {
      ...(existingDay ?? {
        date: getTodayDate(),
        attendance: [],
        events: [],
      }),
      date: getTodayDate(),
      attendance,
      events,
    };

    saveDay(updatedDay);
  }, [attendance, events, hasLoaded]);

  const attendanceRows = useMemo(() => {
    return operatives.map((operative) => {
      const record = attendance.find(
        (item) => String(item.operativeId) === String(operative.id)
      );

      const hours = calculateHours(record?.signIn, record?.signOut);
      const cost = hours * operative.hourlyRate;

      return {
        operative,
        record,
        hours,
        cost,
      };
    });
  }, [attendance]);

  const totals = useMemo(() => {
    return attendanceRows.reduce(
      (summary, row) => {
        const hasAttendance = Boolean(
          row.record?.signIn || row.record?.signOut
        );

        return {
          operatives: summary.operatives + (hasAttendance ? 1 : 0),
          hours: summary.hours + row.hours,
          cost: summary.cost + row.cost,
        };
      },
      {
        operatives: 0,
        hours: 0,
        cost: 0,
      }
    );
  }, [attendanceRows]);

  function updateAttendance(
    operative: Operative,
    field: "signIn" | "signOut",
    value: string
  ) {
    setAttendance((current) => {
      const existingRecord = current.find(
        (record) =>
          String(record.operativeId) === String(operative.id)
      );

      if (existingRecord) {
        return current.map((record) =>
          String(record.operativeId) === String(operative.id)
            ? {
                ...record,
                [field]: value,
              }
            : record
        );
      }

      const newRecord: AttendanceRecord = {
        operativeId: String(operative.id),
        signIn: field === "signIn" ? value : "",
        signOut: field === "signOut" ? value : "",
      };

      return [...current, newRecord];
    });
  }

  function signInNow(operative: Operative) {
    updateAttendance(operative, "signIn", getCurrentTime());
  }

  function signOutNow(operative: Operative) {
    updateAttendance(operative, "signOut", getCurrentTime());
  }

  function clearRecord(operativeId: string) {
    setAttendance((current) =>
      current.filter(
        (record) =>
          String(record.operativeId) !== String(operativeId)
      )
    );
  }

  const today = new Date().toLocaleDateString("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <main className="timeline-page">
      <section className="timeline-panel">
        <header className="timeline-header">
          <div>
            <p className="eyebrow">{today}</p>
            <h1>Attendance</h1>
          </div>

          <div
            style={{
              display: "flex",
              gap: 10,
              flexWrap: "wrap",
            }}
          >
            <Link href="/crews" className="secondary-button">
              Crew Setup
            </Link>

            <Link href="/timeline" className="secondary-button">
              Timeline
            </Link>
          </div>
        </header>

        <section className="attendance-summary">
          <div>
            <span className="attendance-summary-number">
              {totals.operatives}
            </span>

            <span className="attendance-summary-label">
              Operatives
            </span>
          </div>

          <div>
            <span className="attendance-summary-number">
              {formatHours(totals.hours)}
            </span>

            <span className="attendance-summary-label">
              Total hours
            </span>
          </div>

          <div>
            <span className="attendance-summary-number">
              {formatCurrency(totals.cost)}
            </span>

            <span className="attendance-summary-label">
              Total labour cost
            </span>
          </div>
        </section>

        <div className="attendance-table-wrapper">
          <table className="attendance-table">
            <thead>
              <tr>
                <th>Company</th>
                <th>Name</th>
                <th>Position</th>
                <th>Sign In</th>
                <th>Sign Out</th>
                <th>Hours</th>
                <th>Labour Rate</th>
                <th>Cost</th>
                <th aria-label="Actions" />
              </tr>
            </thead>

            <tbody>
              {attendanceRows.map(
                ({ operative, record, hours, cost }) => (
                  <tr key={operative.id}>
                    <td>{operative.company}</td>

                    <td>
                      <strong>{operative.name}</strong>
                    </td>

                    <td>{operative.position}</td>

                    <td>
                      <div className="attendance-time-control">
                        <input
                          type="time"
                          value={record?.signIn ?? ""}
                          onChange={(event) =>
                            updateAttendance(
                              operative,
                              "signIn",
                              event.target.value
                            )
                          }
                          aria-label={`Sign in time for ${operative.name}`}
                        />

                        {!record?.signIn && (
                          <button
                            type="button"
                            className="secondary-button"
                            onClick={() => signInNow(operative)}
                          >
                            Now
                          </button>
                        )}
                      </div>
                    </td>

                    <td>
                      <div className="attendance-time-control">
                        <input
                          type="time"
                          value={record?.signOut ?? ""}
                          onChange={(event) =>
                            updateAttendance(
                              operative,
                              "signOut",
                              event.target.value
                            )
                          }
                          aria-label={`Sign out time for ${operative.name}`}
                        />

                        {record?.signIn && !record?.signOut && (
                          <button
                            type="button"
                            className="secondary-button"
                            onClick={() => signOutNow(operative)}
                          >
                            Now
                          </button>
                        )}
                      </div>
                    </td>

                    <td>{formatHours(hours)}</td>

                    <td>
                      {formatCurrency(operative.hourlyRate)}
                    </td>

                    <td>{formatCurrency(cost)}</td>

                    <td>
                      {(record?.signIn || record?.signOut) && (
                        <button
                          type="button"
                          className="secondary-button"
                          onClick={() =>
                            clearRecord(String(operative.id))
                          }
                        >
                          Clear
                        </button>
                      )}
                    </td>
                  </tr>
                )
              )}
            </tbody>

            <tfoot>
              <tr>
                <th colSpan={5}>Totals</th>
                <th>{formatHours(totals.hours)}</th>
                <th />
                <th>{formatCurrency(totals.cost)}</th>
                <th />
              </tr>
            </tfoot>
          </table>
        </div>
      </section>
    </main>
  );
}