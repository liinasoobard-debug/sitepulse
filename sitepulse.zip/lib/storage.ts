export const STORAGE_KEY = "sitepulse-day";

export function loadDay() {
  if (typeof window === "undefined") return null;

  const data = localStorage.getItem(STORAGE_KEY);

  return data ? JSON.parse(data) : null;
}

export function saveDay(data: unknown) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}